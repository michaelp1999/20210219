package com.company;

import java.util.Scanner;

public class LoanCalculator {
    public static void main(String[] args) {
        System.out.println("Let's  the fixed monthly payment (P) required to fully amortize a loan of L dollars over a term of n months at a monthly interest rate of c ");

        System.out.println("Please enter the loan amount: ");
        Scanner loan_amount = new Scanner(System.in);
        float l = loan_amount.nextFloat();

        System.out.println("Please enter the loan term in months: ");
        Scanner loan_term = new Scanner(System.in);
        float n = loan_term.nextFloat();

        System.out.println("Please enter the monthly interest  rate: ");
        Scanner interest_rate = new Scanner(System.in);
        float c = interest_rate.nextFloat();

        System.out.println("the fixed monthly payment (P) required to fully amortize your loan is");
        float fixed_monthly_payment = l * ( c ( 1 + c ) n ) / ( ( 1 + c ) n - 1);
        System.out.println("The fixed monthly payment is " + fixed_monthly_payment);



    }
}


//P = L[c(1 + c)n]/[(1 + c)n - 1]
//L dollars over a term of n months at a monthly interest rate of c