package com.company;

public class FizzBuzz {
    public static void main(String[] args) {

        int i;
        for(i=1; i<101; i++){

            if (i%3 == 0 && i%5 == 0){
                System.out.println("FIZZBUZZ");
            } else if (i%3 == 0) {
                System.out.println("Fizz");
            }
              else if (i%5 == 0) {
                System.out.println("BUZZ");
            }
            else  {
                System.out.println(i);
            }

        }

    }
}
