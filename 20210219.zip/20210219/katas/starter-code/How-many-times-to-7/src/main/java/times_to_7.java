

public class times_to_7 {
    public static void main(String[] args) {


        int i;
        for(i=0; i < 101; i++ ) {
            int die1 = (int) (Math.random() * 6) + 1;
            int die2 = (int)(Math.random()*6) + 1;
            int roll = die1 + die2;

            System.out.println("The first die comes up " + die1);
            System.out.println("The second die comes up " + die2);
            System.out.println("Your total roll is " + roll);

            int counter = 0;
            if (roll == 7) {
                counter++;
            }
             System.out.println(counter);
        }
    }
}

