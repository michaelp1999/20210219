public class times_to_7 {
}
