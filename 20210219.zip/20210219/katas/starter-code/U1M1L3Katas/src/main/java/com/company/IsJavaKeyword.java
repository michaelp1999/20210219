package com.company;

import java.util.Scanner;

public class IsJavaKeyword {

    public static void main(String[] args) {

        System.out.println("Please enter a word: ");
        Scanner user_input = new Scanner(System.in);
        String word = user_input.nextLine();

        if (word.equals("abstract")) {
            System.out.println("This is a Java Language Keyword");
        } else if (word.equals("continue")) {
            System.out.println("This is a Java Language Keyword");
        } else if (word.equals("for")) {
            System.out.println("This is a Java Language Keyword");
        } else if (word.equals("new")) {
            System.out.println("This is a Java Language Keyword");
        } else if (word.equals("switch")) {
            System.out.println("This is a Java Language Keyword");
        } else if (word.equals("assert***")) {
            System.out.println("This is a Java Language Keyword");
        } else if (word.equals("default")) {
            System.out.println("This is a Java Language Keyword");
        } else if (word.equals("goto*")) {
            System.out.println("This is a Java Language Keyword");
        } else if (word.equals("package")) {
            System.out.println("This is a Java Language Keyword");
        } else if (word.equals("synchronized")) {
            System.out.println("This is a Java Language Keyword");
        } else if (word.equals("boolean")) {
            System.out.println("This is a Java Language Keyword");
        } else if (word.equals("do")) {
            System.out.println("This is a Java Language Keyword");
        } else if (word.equals("if")) {
            System.out.println("This is a Java Language Keyword");
        } else if (word.equals("private")) {
            System.out.println("This is a Java Language Keyword");
        }
    }
}

// please note the above is only a sample of java keywords