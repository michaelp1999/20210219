package com.company;

import java.util.Scanner;

public class FavoriteProgrammingLanguage {

    public static void main(String[] args) {
        String java = "java";
        Scanner user_input = new Scanner(System.in);
        System.out.println("Please enter the name of your favorite programming language: ");
        String user_language = user_input.nextLine();

        while (user_language != "java") {
            System.out.println("Please enter another language: ");
            user_language = user_input.nextLine();
        }

        System.out.println("That's what I was looking for! Java is definitely the answer!");
    }
}