package com.company;

import java.util.Scanner;

public class CountByThirteen {

    public static void main(String[] args) {

            System.out.println("PLease enter any number (integers only!): ");
            Scanner scanner = new Scanner(System.in);
            int user_input = scanner.nextInt();

            for (int i = 0; i <= user_input; i+=13) {
                System.out.println(i);
            }
        }
    }