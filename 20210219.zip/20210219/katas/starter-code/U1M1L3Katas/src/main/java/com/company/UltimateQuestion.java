package com.company;

import java.util.Scanner;

public class UltimateQuestion {

    public static void main(String[] args) {

        int num = 42;
        Scanner user_input = new Scanner(System.in);
        System.out.println("Please enter an integer between 1 and 100");
        int user_number = user_input.nextInt();

        while (user_number != num) {
            System.out.println("Please enter a number in the range 1 and 100: ");
            user_number = user_input.nextInt();
        }

        System.out.println("That's the number I was looking for! 42 is definitely the answer!");
    }
}
