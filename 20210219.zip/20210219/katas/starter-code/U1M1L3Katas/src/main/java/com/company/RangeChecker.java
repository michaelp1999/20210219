package com.company;

import java.util.Scanner;

public class RangeChecker {

    public static void main(String[] args) {
        System.out.println("Please enter a number between between 15 and 32: ");
        Scanner scanner = new Scanner (System.in);
        int user_input = scanner.nextInt();
        System.out.println("the number you entered is: " + user_input);


        while (user_input > 32 || user_input < 15) {
            System.out.println("Please enter a number in the range 15 and 32: ");
            user_input = scanner.nextInt();

        }

        System.out.println("the number you entered is in the range");

    }
}
