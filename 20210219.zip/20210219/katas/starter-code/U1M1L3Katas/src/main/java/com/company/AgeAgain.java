package com.company;

import java.util.Scanner;

public class AgeAgain {

    public static void main(String[] args) {
        System.out.println("Please enter your age" );
        Scanner user_input = new Scanner(System.in);
        int age = user_input.nextInt();

        if (age < 14){
            System.out.println("What grade are you in? ");
            int grade = user_input.nextInt();
            System.out.println("Wow! " + grade + " - that sounds exciting!");
        } else if (14 <= age <= 18){
            System.out.println("Are you planning on gong to college? (Answer 'yes' or 'no'");
            String answer = user_input.nextLine();
                if (answer == 'yes') {
                    System.out.println("What college are you going to? ");
                    String college = user_input.nextLine();
                    System.out.println(college + " is a great school");
                } else {
                    System.out.println("What are your plans? ");
                    String plans = user_input.nextLine();
                    System.out.println("Wow!" + plans + " sounds like a plan!");

                }
        else {
            System.out.println("What is your job?");
            String job = user_input.nextLine();
            System.out.println(job + " sounds like a great job!");
            }


        }
    }
}
