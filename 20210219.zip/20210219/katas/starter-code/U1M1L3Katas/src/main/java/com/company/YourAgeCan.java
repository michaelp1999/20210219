package com.company;

import java.util.Scanner;

public class YourAgeCan {

    public static void main(String[] args) {
        Scanner user_input = new Scanner(System.in);
        System.out.println("Please enter your age: ");
        int age = user_input.nextInt();



        if ( age > 18) {
            System.out.println("You can vote");
        } else if (age > 21) {
            System.out.println("You can vote");
            System.out.println("You can drink");
        } else if (age > 35) {
            System.out.println("You can vote");
            System.out.println("You can drink");
            System.out.println("You can be president");
        } else if (age > 55) {
            System.out.println("You can vote");
            System.out.println("You can drink");
            System.out.println("You can be president");
            System.out.println("You are eligible for AARP");
        } else if (age > 65) {
            System.out.println("You can vote");
            System.out.println("You can drink");
            System.out.println("You can be president");
            System.out.println("You are eligible for AARP");
            System.out.println("You can retire");
        } else if (age > 80) {
            System.out.println("You can vote");
            System.out.println("You can drink");
            System.out.println("You can be president");
            System.out.println("You are eligible for AARP");
            System.out.println("You can retire");
            System.out.println("You are octogenarian");
        } else if (age > 100) {
            System.out.println("You can vote");
            System.out.println("You can drink");
            System.out.println("You can be president");
            System.out.println("You are eligible for AARP");
            System.out.println("You can retire");
            System.out.println("You are octogenarian");
            System.out.println("You are more than a century old");

        }
    }
}
