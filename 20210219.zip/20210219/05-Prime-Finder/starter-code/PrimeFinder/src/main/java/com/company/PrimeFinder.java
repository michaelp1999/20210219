package com.company;

import java.util.Scanner;

public class PrimeFinder {
    public static void main(String[] args) {
        {

            Scanner scan = new Scanner(System.in);
            System.out.println("Enter any number:");

            int num = scan.nextInt();
        }}}