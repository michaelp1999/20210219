package com.company;

import java.util.Scanner;
import java.util.Random;

public class HiLo {
    public static void main(String[] args) {

        System.out.println("Welcome to to Hi-Low!");
        System.out.println("Please enter your name: ");
        Scanner user_input = new Scanner(System.in);
        String name = user_input.nextLine();
        System.out.println("OK, " + name + "," + " here are the rules:");

        System.out.println("Let's play the guessing game");
        System.out.println("The computer has generated a number...");
        System.out.println("Please guess what it is");
        Random generator = new Random();
        int i = generator.nextInt(100) + 1;

        int guess;
        int count = 0;

        do {
            System.out.print("Enter a guess: (1-100) ");
            System.out.println("Please enter your guess:");
            guess = user_input.nextInt();
            count++;
            System.out.println("Your guess is " + guess);

            if (guess == i) {
                System.out.println("Your guess is correct. Congratulations!");
                System.out.println("It took you " + count + " guesses to find my number!");

            } else if (guess < i) {

                System.out.println("Too low");
                System.out.print("Enter another guess please: (1-100) ");
                guess = user_input.nextInt();

            } else if (guess > i) {
                System.out.println("Too high!");
                System.out.print("Enter another guess please: (1-100) ");
                guess = user_input.nextInt(); }

        } while (guess != i);




        //THIS IS ALL SCRAP BELOW
        /*
        if (i == user_guess) {
            System.out.println("Congratulations," + name + "!" + "You win!");
        } else if (user_guess > i) {
            System.out.println("Too high");
        } else if ( user_guess < i) {
            System.out.println("Too low");
        }
        */



    }
}
